

<?php
try{
		$conn = new MongoDB\Driver\Manager("mongodb://localhost:27017");
	} catch (MongoDBDriverExceptionException $e) {
		echo 'Failed to connect to MongoDB, is the service intalled and running?<br /><br />';
		echo $e->getMessage();
		exit();
	}


$players = array(array('uname'=>'Sushan', 'Score'=> '21'),
array('uname'=>'Sushan', 'Score'=> '21'),
array('uname'=>'Anshit', 'Score'=> '15'),
array('uname'=>'Vishal', 'Score'=> '7'),
array('uname'=>'Raj', 'Score'=> '20'),
array('uname'=>'Aditeya', 'Score'=> '19'),
array('uname'=>'Omesh', 'Score'=> '14'),
array('uname'=>'Suraj', 'Score'=> '5'),
array('uname'=>'Rajauria', 'Score'=> '10'),
array('uname'=>'Patwa', 'Score'=> '2'),
array('uname'=>'Bhushan', 'Score'=> '11'),
array('uname'=>'TirthMota', 'Score'=> '9'),
);

$cmd = new MongoDB\Driver\Command(['listDatabases' => 1]);
	try {
		$result = $conn->executeCommand('admin', $cmd);
		$dbArray = $result->toArray()[0];
	} catch(MongoDB\Driver\Exception $e) {
		echo $e->getMessage().'<br />';
		exit;
	}

	if(!array_search('player', array_column($dbArray->databases, 'name'))){
		echo 'player database doesn\'t exist, creating it<br />';
 

		if(!array_search('player', array_column($dbArray->databases, 'name'))){
		echo 'phpDemo database doesn\'t exist, creating it<br />';
		foreach($players AS $player1){
			$row = new MongoDB\Driver\BulkWrite();
			$row->insert($player1);
			$conn->executeBulkWrite('player.player1', $row);
			
		}
	} 

	$query = new MongoDB\Driver\Query([],[]);
	$result = $conn->executeQuery('player.player1', $query);
}

if($result){
		echo '<h3>Reading data from MongoDB</h3>'.
		'<table width="500" align="center">'.
			'<thead>'.
				'<tr><th>_id</th><th>Player</th><th>Score</th></tr>'.
			'</thead>'.
			'<tbody>';
				foreach ($result as $rs){
					echo '<tr><td>'.$rs->{'_id'}.'</td><td>'.$rs->uname.'</td><td>'.$rs->Score.'</td></tr>';
				}
			echo '</tbody>'.
		'</table>';
		unset($query, $result);
		
		}
	
?>

